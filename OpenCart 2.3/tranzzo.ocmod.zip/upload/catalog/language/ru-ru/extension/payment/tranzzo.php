<?php
// Text
$_['text_title']		= 'Оплата через TRANZZO';
$_['text_credit_card']	= 'Подтверждение платежа';
$_['text_loading']		= 'Загрузка...';
$_['text_pay_success']		= 'The order was successfully paid through TRANZZO';
$_['text_payment_id']		= 'ID платежа(payment id)';
$_['text_transaction']		= 'ID транзакции(transaction id)';
