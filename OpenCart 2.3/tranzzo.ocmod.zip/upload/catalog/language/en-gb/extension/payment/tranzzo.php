<?php
// Text
$_['text_title']		= 'Payment through TRANZZO';
$_['text_credit_card']	= 'Payment Confirmation';
$_['text_loading']		= 'Loading...';
$_['text_pay_success']		= 'The order was successfully paid through TRANZZO';
$_['text_payment_id']		= 'Payment id';
$_['text_transaction']		= 'Transaction id';


