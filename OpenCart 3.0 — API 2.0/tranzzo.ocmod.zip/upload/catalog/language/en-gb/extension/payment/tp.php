<?php
$_['text_title']		= 'Payment through %1$s';
$_['text_credit_card']	= 'Payment Confirmation';
$_['text_loading']		= 'Loading...';
$_['text_pay_success']	= 'The order was successfully paid in %1$s. For the sum of %2$s';
$_['text_pay_auth']		= 'Payment was successfully reserved through %1$s. Preauthorized funds can be captured via the merchant portal';
$_['text_pay_void']		= 'Payment was successfully unlocked through %1$s';
$_['text_payment_id']	= 'Payment id';
$_['text_order']		= 'Order id';
$_['text_pay_refund']	= 'The order was successfully refund through %1$s';

